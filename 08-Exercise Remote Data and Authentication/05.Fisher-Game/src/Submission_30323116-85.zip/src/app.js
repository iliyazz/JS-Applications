window.addEventListener('DOMContentLoaded', onLoadHTML)
document.querySelectorAll('a').forEach(x => x.classList.remove('active'));
document.getElementById('login').classList.add('home');
document.getElementById('addForm').addEventListener('submit', createCatch)
document.getElementById('logout').addEventListener('click', onLogout);
document.querySelector('.load').addEventListener('click', onLoadCatch);
let div = document.getElementById('catches');




async function onLogout() {
    const url = 'http://localhost:3030/users/logout';
    const header = getHeader('GET', '');
    const response = await fetch(url, header);
    sessionStorage.clear();
    div.innerHTML = '';
    onLoadHTML();
}




function onLoadHTML() {
    const token = sessionStorage.getItem('accessToken');
    const userName = document.querySelector('p.email span');
    const addBtn = document.querySelector('.add');
    if (token) {
        document.getElementById('guest').style.display = 'none';
        document.getElementById('user').style.display = 'inline-block';
        userName.innerHTML = sessionStorage.getItem('email');
        addBtn.disabled = false;
    }
    else {
        document.getElementById('guest').style.display = 'inline-block';
        document.getElementById('user').style.display = 'none';
        userName.innerHTML = 'guest';
        addBtn.disabled = true;
    }
}

async function onLoadCatch() {
    const url = 'http://localhost:3030/data/catches';
    const response = await fetch(url);
    const data = await response.json();
    await renderCatches(data);
}

function renderCatches(data) {
    div.innerHTML = '';
    const html = 

    data.map(x => {
        let divInner = createEl('div', null, 'catch', null, null);
        let isAuthor = data && x._ownerId !== sessionStorage._id;
        //angler
        divInner.appendChild(createEl('label', 'Angler', null, null, null, null));
        divInner.appendChild(createEl('input', x.angler, 'angler', null, 'text', isAuthor));
        divInner.appendChild(createEl('label', 'Weight', null, null, null, null));
        divInner.appendChild(createEl('input', Number(x.weight), 'weight', null, 'text', isAuthor));
        //species
        divInner.appendChild(createEl('label', 'Species', null, null, null, null));
        divInner.appendChild(createEl('input', x.species, 'species', null, 'text', isAuthor));
        //location
        divInner.appendChild(createEl('label', 'Location', null, null, null, null));
        divInner.appendChild(createEl('input', x.location, 'location', null, 'text', isAuthor));
        //bait
        divInner.appendChild(createEl('label', 'Bait', null, null, null, null));
        divInner.appendChild(createEl('input', x.bait, 'bait', null, 'text', isAuthor));
        //captureTime
        divInner.appendChild(createEl('label', 'Capture Time', null, null, null, null));
        divInner.appendChild(createEl('input', Number(x.captureTime), 'captureTime', null, 'text', isAuthor));
        //buttons
        let updateBtn = createEl('button', 'Update', 'update', null, null);
        updateBtn.setAttribute('data-id', x._ownerId);
        updateBtn.id = x._id;
        updateBtn.addEventListener('click', onUpdate);
        x._ownerId !== sessionStorage._id ? updateBtn.disabled = true : updateBtn.disabled = false;
        divInner.appendChild(updateBtn);
        let deleteBtn = createEl('button', 'Delete', 'delete', null, null);
        deleteBtn.setAttribute('data-id', x._ownerId);
        deleteBtn.id = x._id;
        deleteBtn.addEventListener('click', onDelete);
        x._ownerId !== sessionStorage._id ? deleteBtn.disabled = true : deleteBtn.disabled = false;
        divInner.appendChild(deleteBtn);
        div.appendChild(divInner);

    }

    )

}

async function onUpdate(e) {
    const token = sessionStorage.getItem('accessToken');
    const url = `http://localhost:3030/data/catches/${e.target.id}`;
    const data = e.target.parentElement.querySelectorAll('input');
    let object = { "angler": data[0].value, "weight": data[1].value, "species": data[2].value, "location": data[3].value, "bait": data[4].value, "captureTime": data[5].value };
    const response = await fetch(url, {
        method: 'put',
        headers: {
            'Content-Type': 'application/json',
            'X-Authorization': token
        },
        body: JSON.stringify(object)
    })
}

async function onDelete(e) {
    const token = sessionStorage.getItem('accessToken');
    const url = `http://localhost:3030/data/catches/${e.target.id}`;
    await fetch(url, {
        method: 'delete',
        headers: {
            'Content-Type': 'application/json',
            'X-Authorization': token
        }
    });
    e.target.parentElement.remove();
}
function createEl(tag, text = null, className = null, id = null, type = null, isAuthor = null) {
    let el = document.createElement(tag);
    if (tag !== 'input') { if (text) { el.textContent = text; } }
    else { if (text) { el.value = text; } }
    if (type) { el.type = type; }
    if (id) { el.id = id; }
    if (className) { el.className = className; }
    if (isAuthor) { el.disabled = true } else { el.disabled = false }
    return el;
}


function createCatch(e) {
    e.preventDefault();
    const form = e.target;
    const formData = new FormData(form);
    const data = Object.fromEntries(formData);




    const angler = formData.get('angler');
    const weight = Number(formData.get('weight'));
    const species = formData.get('species');
    const location = formData.get('location');
    const bait = formData.get('bait');
    const captureTime = Number(formData.get('captureTime'));

    if (angler && Number(weight) && species && location && bait && Number(captureTime)) {
        onCreateCatch(data);
        e.target.reset();
    }
    else {
        return alert('All fields are required!');
    }

}

async function onCreateCatch(body) {
    const url = 'http://localhost:3030/data/catches';
    const header = getHeader('post', body)
    const response = await fetch(url, header);
    const data = await response.json();
}


function getHeader(method, body) {
    const token = sessionStorage.getItem('accessToken');
    const header = {
        method: `${method}`,
        headers: {
            'Content-Type': 'application/json',
            'X-Authorization': token
        },
    }
    if (body) {
        header.body = JSON.stringify(body);
    }
    return header;
}