import { html, render } from './node_modules/lit-html/lit-html.js';
import { towns } from './towns.js';

const townsRoot = document.getElementById('towns');
const resultRoot = document.getElementById('result');
document.querySelector('button').addEventListener('click', search)

update();

function update(text) {
    const ul = searchTemplate(towns, text);
    render(ul, townsRoot);
}

function searchTemplate(towns, match) {
    const ul = html`
    <ul>
        ${towns.map(town => createTemplate(town, match))}
    </ul>
    `;
    return ul;
}

function createTemplate(town, match) {
    return html`
    <li class="${(match && town.toLowerCase().includes(match)) ? " active" : "" }">
        ${town}
    </li>
    `
}

function search() {
    const inputText = document.getElementById('searchText');
    const text = inputText.value.toLowerCase();
    update(text);
    updateCount();
}

function updateCount() {
    const count = document.querySelectorAll('.active').length;
    const countEl = count ? html`<p>${count} matches found</p>` : "";
    render(countEl, resultRoot);
}
